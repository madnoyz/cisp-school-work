Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdNew As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents barSpeed As System.Windows.Forms.HScrollBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.barSpeed = New System.Windows.Forms.HScrollBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmdNew = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Enabled = False
        Me.Button1.Location = New System.Drawing.Point(64, 16)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(8, 256)
        Me.Button1.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.Enabled = False
        Me.Button2.Location = New System.Drawing.Point(200, 16)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(8, 256)
        Me.Button2.TabIndex = 1
        '
        'Button3
        '
        Me.Button3.Enabled = False
        Me.Button3.Location = New System.Drawing.Point(336, 16)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(8, 256)
        Me.Button3.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.barSpeed, Me.Label3, Me.Label2, Me.cmdNew, Me.Label1})
        Me.Panel1.Location = New System.Drawing.Point(0, 272)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(408, 48)
        Me.Panel1.TabIndex = 6
        '
        'barSpeed
        '
        Me.barSpeed.LargeChange = 1
        Me.barSpeed.Location = New System.Drawing.Point(8, 8)
        Me.barSpeed.Maximum = 10
        Me.barSpeed.Name = "barSpeed"
        Me.barSpeed.Size = New System.Drawing.Size(328, 17)
        Me.barSpeed.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(280, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Slower"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Faster"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdNew
        '
        Me.cmdNew.Location = New System.Drawing.Point(348, 10)
        Me.cmdNew.Name = "cmdNew"
        Me.cmdNew.Size = New System.Drawing.Size(48, 24)
        Me.cmdNew.TabIndex = 2
        Me.cmdNew.Text = "New"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(168, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Speed"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmMain
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(408, 318)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel1, Me.Button1, Me.Button2, Me.Button3})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmMain"
        Me.Text = "Towers of Hanoi"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    '3 posts, each a stack that will contain up to 32 rings:
    Dim Posts As Stack() = New Stack(2) {New Stack(32), New Stack(32), New Stack(32)}
    Dim threadHanoi As New Threading.Thread(AddressOf hanoi)
    Dim n As Byte

    Private Sub Animate_Up(ByRef butn As Button)
        ' determine destination:
        Dim destination_top = 4
        ' move 1 pixel at a time to the destination:
        While (butn.Top > destination_top)
            butn.Top -= 1
            threadHanoi.Sleep(barSpeed.Value)
        End While
    End Sub
    Private Sub Animate_Over(ByRef butn As Button, ByVal peg As Byte)
        ' determine destination:
        Dim destination_left = 136 * peg + (68 - butn.Width / 2)
        ' if moving to the left:
        If butn.Left > destination_left Then
            ' move to the left 1px at a time:
            While (butn.Left > destination_left)
                butn.Left -= 1
                threadHanoi.Sleep(barSpeed.Value)
            End While
        Else
            ' otherwise moving to the right:
            ' move to the right 1px at a time:
            While (butn.Left < destination_left)
                butn.Left += 1
                threadHanoi.Sleep(barSpeed.Value)
            End While
        End If
    End Sub
    Private Sub Animate_Down(ByRef butn As Button, ByVal count As Byte)
        ' determine destination:
        Dim destination_top = 272 - 8 * count
        ' move 1 pixel at a time to the destination:
        While (butn.Top < destination_top)
            butn.Top += 1
            threadHanoi.Sleep(barSpeed.Value)
        End While
    End Sub
    Private Sub moveDisk(ByRef fromPole As Byte, ByRef toPole As Byte)
        'Push onto the goal the popped one from the start:
        Posts(toPole).Push(Posts(fromPole).Pop)
        ' 3 functions to animate the movement:
        Animate_Up(Posts(toPole).Peek())
        Animate_Over(Posts(toPole).Peek(), toPole)
        Animate_Down(Posts(toPole).Peek(), Posts(toPole).Count)
    End Sub
    Private Sub hanoi(ByVal N As Byte, ByVal Start As Byte, ByVal Goal As Byte, ByVal Spare As Byte)
        If (N = 1) Then
            ' move the disk to the goal peg
            moveDisk(Start, Goal)
        Else
            ' move the disks above the target disk to the spare peg
            hanoi(N - 1, Start, Spare, Goal)
            ' move the "target" disk to the goal peg
            moveDisk(Start, Goal)
            ' move the disks from the spare peg to the goal peg
            hanoi(N - 1, Spare, Goal, Start)
        End If
    End Sub
    Private Sub addRings(ByVal size As Byte)
        Dim butn As Button
        Dim i As Byte
        ' add however many rings the user specified:
        For i = 0 To size - 1
            butn = New Button()
            butn.Size = New Size(136 - 4 * i, 8)
            butn.Location = New Point(i * 2, 264 - i * 8)
            Me.Controls.Add(butn)
            butn.BringToFront()
            ' push them onto the peg's stack
            Posts(0).Push(butn)
        Next
    End Sub
    Private Sub cmdNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNew.Click
        ' ****** cleanup from previous run:
        ' if thread is on, turn it off:
        If threadHanoi.IsAlive Then
            threadHanoi.Abort()
        End If
        Dim butn As Button
        For Each butn In Posts(0)
            butn.Dispose()
        Next
        Posts(0).Clear()
        For Each butn In Posts(1)
            butn.Dispose()
        Next
        Posts(1).Clear()
        For Each butn In Posts(2)
            butn.Dispose()
        Next
        Posts(2).Clear()
        ' ******* end cleanup

        ' ******* get valid input for # rings:
        Dim i As Byte = 33
        Dim input As String
        While (i < 0 Or i > 32)
            input = InputBox("Input the number of rings (1-32):", "Towers", 4)
            If (input = "") Then
                i = 0
            Else
                Try
                    i = Integer.Parse(input)
                Catch
                    MsgBox("Invalid Input. Use a number from 1 to 32", , "Error")
                End Try
            End If
        End While
        ' ******* end valid input

        ' 0 represents a cancel by user:
        If i > 0 Then
            ' add the rings to the peg:
            addRings(i)
            ' refresh the form to show it:
            Me.Refresh()
            ' set the global variable so the thread an access it:
            n = i
            ' new thread:
            threadHanoi = New Threading.Thread(AddressOf hanoi)
            ' start thread:
            threadHanoi.Start()
        End If
    End Sub
    Private Sub hanoi()
        hanoi(n, 0, 1, 2)
    End Sub
    Private Sub frmMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        ' if thread is on, turn it off:
        If threadHanoi.IsAlive Then
            threadHanoi.Abort()
        End If
    End Sub
End Class
