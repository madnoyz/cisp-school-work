package decipher.frequency;

public class Frequency {

	private int count = 0;
	
	public void increment() {
		this.count++;
	}
	
	public int getCount() {
		return this.count;
	}

}
